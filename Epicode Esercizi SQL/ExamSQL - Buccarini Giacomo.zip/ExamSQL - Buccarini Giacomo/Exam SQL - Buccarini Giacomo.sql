create schema ToysGroup_ExamSQL_GiacomoBuccarini;

create table Product (
Product_ID int primary key not null,
Name varchar(50),
Price double,
Category varchar (50));

create table Region (
Region_ID int primary key not null,
Sales_ID int not null,
State varchar (50),
Address varchar (100),
TelephoneNUmber varchar (50)
);

create table Sales(
Sales_ID int primary key not null,
Region_ID int not null,
Product_ID int not null, 
SalesPrice double,
OrderDate date,
foreign key (Product_ID) references Product (Product_ID), 
foreign key (Region_ID) references Region (Region_ID)
);

alter table Sales add Amount decimal;

select * from sales;

insert into Product (Product_ID, Name, Price, Category )values
('1', 'Barbie', '49.99', 'Bambole'),
('2', 'Unicorno', '9.99', 'Peluches'),
('3', 'Bugs_Bunny', '15.99', 'Peluches'),
('4', 'Tappeto', '19.99', 'Prima_Infanzia'),
('5', 'Chicco_PrimiPassi', '35.99', 'Prima_Infanzia'),
('6' ,'Lego_Marvel', '25.99', 'Costruzioni'),
('7', 'Macchina_Telecomandata', '58.99', 'Veicoli'),
('8', 'Frozen', '39.99', 'Bambole'),
('9', 'Elicottero', '25.99', 'Veicoli'),
('10', 'Monopoly', '34.99', 'Giochi_Tavolo');

select * from product;

insert into Region (Region_ID, Sales_ID, State, Address, TelephoneNumber) values
('0039', '12', 'Italia', 'Corso Vittorio Emanuele II, 24 Milano', '00390297131860'),
('0034', '34', 'Spagna', 'C. de San Agustín 18, Madrid', '0034913763614'),
('0033', '56', 'Francia', '146 Rue de Rivoli, Parigi', '0033186905891'),
('0049', '78', 'Germania', 'Leipziger Pl. 12, Berlino', '004930586888370'),
('0044', '910', 'Inghilterra', '188-196 Regent St., Londra', '00443717041977'),
('0031', '112', 'Olanda', 'Kalverstraat 230, Amsterdam', '0031883343531');

select * from region;

insert into Sales (Sales_ID, Region_ID, Product_ID, SalesPrice, OrderDate, Amount) values
('12','0044','9','25.99','2023-10-03','1'),
('34','0033','3','47.97','2023-10-15','3'),
('56','0039','2','19.98','2023-11-16','2'),
('78','0039','4','99.95','2023-12-03','5'),
('910','0049','8','119.97','2024-01-05','3'),
('112','0034','10','139.96','2024-01-05', '4'),
('125','0033','10','69.98','2024-01-10','2'),
('130','0039','10','139.96','2024-01-10','4'),
('145','0049','4','99.95','2024-01-05','5'),
('156','0031','2','69.93','2023-12-03','7'),
('134','0033','9','51.98','2023-11-16','2');


select * from sales;

-- 1. Verificare che i campi definiti come PK siano univoci. 

show columns from product;
show columns from region;
show columns from sales;

-- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.  

SELECT DISTINCT
    product.name,
    SUM(sales.SalesPrice),
    YEAR(sales.orderdate) AS Year
FROM
    sales
        JOIN
    product ON product.Product_ID = sales.Product_ID
GROUP BY product.name , Year;

-- 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 

SELECT 
    region.state,
    YEAR(orderdate) AS Year,
    SUM(SalesPrice) AS Profit
FROM
    sales
        JOIN
    region ON sales.Region_ID = region.Region_ID
GROUP BY region.state , OrderDate
ORDER BY Year , Profit DESC;

 
-- 4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 

SELECT 
    product.category, SUM(sales.amount) AS TotAmount
FROM
    product
        JOIN
    sales ON product.Product_ID = sales.Product_ID
GROUP BY product.category
ORDER BY TotAmount DESC;


-- 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 

SELECT 
    *
FROM
    product
WHERE
    product.name NOT IN (SELECT 
            product.name
        FROM
            product
                JOIN
            sales ON product.Product_ID = sales.Product_ID);
 
 
SELECT 
    *
FROM
    product
        LEFT OUTER JOIN
    sales ON product.Product_ID = sales.Product_ID
WHERE
    sales.Product_ID IS NULL;


-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).

 SELECT 
    product.name, MAX(orderdate) AS ultima_vendita
FROM
    product
        JOIN
    sales ON product.Product_ID = sales.Product_ID
GROUP BY product.name;
 